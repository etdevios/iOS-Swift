
func loveCalculator() {
    let loveScore = Int.random(in: 0 ... 100)
    
    switch loveScore {
    case 81...:
        print("You love each other loke Kanye loves Kanye.")
    case 41..<81:
        print("You go together loke Coke and Mentos")
    default:
        print("You'll be forever alone.")
    }
    
    if loveScore > 80 {
        print("You love each other loke Kanye loves Kanye.")
    } else if loveScore > 40 {
        print("You go together loke Coke and Mentos")
    } else {
        print("You'll be forever alone.")
    }
}

loveCalculator()







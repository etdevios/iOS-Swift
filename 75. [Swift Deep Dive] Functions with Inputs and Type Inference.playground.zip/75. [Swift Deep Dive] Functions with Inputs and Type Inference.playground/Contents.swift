
func greeting() {
    print("hello")
}

//var myAge: String = "Three"

func greeting2(whoToGreet: String) {
    print("Hello \(whoToGreet)")
}

greeting2(whoToGreet: "Angela")
greeting2(whoToGreet: "Eduard")
greeting2(whoToGreet: "Jack Bauer")

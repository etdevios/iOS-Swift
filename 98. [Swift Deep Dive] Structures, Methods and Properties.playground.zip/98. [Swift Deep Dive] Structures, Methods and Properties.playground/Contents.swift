struct Town {
    let name = "Angelaland"
    var citizens = ["Angela", "Jack Bauer"]
    var resources = ["Grain": 100, "Ore": 42, "Wool": 75]
    
    func fortify() {
        print("Defences increased!")
    }
}

var myTown = Town()
print(myTown.citizens)
print("\(myTown.name) has \(myTown.resources["Grain"]!) bags of grain")

myTown.citizens.append("Keanu Reeves")
print(myTown.citizens.count)

myTown.fortify()

struct SomeTown {
    let name: String
    var citizens: [String]
    var resources: [String: Int]
    
    init(name: String, citizens: [String], resouces: [String: Int]) {
        self.name = name
        self.citizens = citizens
        self.resources = resouces
    }
    
    
    func fortify() {
        print("Defences increased!")
    }
}

var anotherTown = SomeTown(name: "Nameless", citizens: ["Tom Hanks"], resouces: ["Coconuts": 100])

anotherTown.citizens.append("Wilson")
print(anotherTown.citizens)

var ghostTown = SomeTown(name: "Ghosy McGhostface", citizens: [], resouces: ["Tumbleweed": 1])


func exercise() {

    // Define the User struct here
    struct User {
        var name: String
        var email: String?
        var followers: Int
        var isActive: Bool
        
        init (name: String, email: String?, followers: Int, isActive: Bool){
            self.name = name
            self.email = email
            self.followers = followers
            self.isActive = isActive
        }
        
        func logStatus() {
            if isActive {
                print("\(name) is working hard")
            } else {
                print("\(name) has left earth")
            }
        }
    }

    // Initialise a User struct here
    let gere = User(name: "Richard", email: nil, followers: 0, isActive: false)
    gere.logStatus()



    // Diagnostic code - do not change this code
    print("\nDiagnostic code (i.e., Challenge Hint):")
    var musk = User(name: "Elon", email: "elon@tesla.com", followers: 2001, isActive: true)
    musk.logStatus()
    print("Contacting \(musk.name) on \(musk.email!) ...")
    print("\(musk.name) has \(musk.followers) followers")
    // sometime later
    musk.isActive = false
    musk.logStatus()
    
}

exercise()


let skeleton1 = Enemy(health: 100, attackStrength: 10)
let skeleton2 = skeleton1

let dragon = Dragon(health: 100, attackStrength: 30)
dragon.wingSpan = 10
dragon.attackStrength = 30

dragon.talk(speech: "My teeth are swords! My claws are spears! My wings are a hurricane!")

dragon.move()
dragon.attack()

skeleton1.takeDamage(amount: 10)
print(skeleton2.health)

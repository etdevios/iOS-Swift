
//This is comment

print("Hello \(2 + 3) World")

/* This is a multiple
 line comment */

print("The result of 5 + 3 = \(5 + 3)")


var a = 5

var b = 8

var c = a
a = b
b = c

print("The value of a is \(a)")
print("The value of b is \(b)")

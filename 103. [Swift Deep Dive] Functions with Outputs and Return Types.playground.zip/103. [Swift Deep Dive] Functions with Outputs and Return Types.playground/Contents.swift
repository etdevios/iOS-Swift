
func greeting1() {
    print("Hello")
}

greeting1()

func greeting2(name: String) {
    print("Hello \(name)")
}

greeting2(name: "Angela")

func greeting3(name: String) -> Bool {
    if name == "Angela" || name == "Jack Bauer" {
        return true
    } else {
        return false
    }
}

var doorShouldOpen = greeting3(name: "Angela")

func isOdd(n: Int) -> Bool {
    if n % 2 == 0 {
        return true
    } else {
        return false
    }
}


//var player1Username: String = nil

var player1Username: String? = nil

player1Username = "jackbauerisawesome"

//var unwrapped1Username = player1Username!

player1Username = nil

if player1Username != nil {
    print(player1Username!)
}

//Don't change this
var studentsAndScores = ["Amy": 88, "James": 55, "Helen": 99]

func highestScore(scores: [String: Int]) {
  
  //Write your code here.
    var highestScore = 0
    for score in scores {
        if score.value > highestScore {
            highestScore = score.value
        }
    }
    print(highestScore)
    
    
}

highestScore(scores: studentsAndScores)

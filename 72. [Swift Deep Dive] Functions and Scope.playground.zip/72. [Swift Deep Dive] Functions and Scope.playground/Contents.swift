
func greeting() {
    print("hello")
}

greeting()
greeting()
greeting()
greeting()


func greeting1() {
    print("hello")
    
    let myName = "Angela"
    
    print(myName)
    
    func greeting2() {
        print("hello")
    }
}


func greeting3() {
    
}

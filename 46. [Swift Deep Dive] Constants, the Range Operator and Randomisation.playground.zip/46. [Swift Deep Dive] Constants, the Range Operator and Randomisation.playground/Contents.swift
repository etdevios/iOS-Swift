
let pi = 3.14159

var score = 22

print(score)

let randomNumber = Float.random(in: 1 ..< 3)

print(randomNumber)

let alphabet = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]


let password = alphabet[Int.random(in: 0 ... 25)] + alphabet[Int.random(in: 0 ... 25)] + alphabet[Int.random(in: 0 ... 25)] + alphabet[Int.random(in: 0 ... 25)] + alphabet[Int.random(in: 0 ... 25)] + alphabet[Int.random(in: 0 ... 25)]

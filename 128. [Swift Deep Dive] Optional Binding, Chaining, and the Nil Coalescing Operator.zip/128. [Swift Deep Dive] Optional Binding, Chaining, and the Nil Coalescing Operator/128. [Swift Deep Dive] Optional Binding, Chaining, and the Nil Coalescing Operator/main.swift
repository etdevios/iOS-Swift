//
//  main.swift
//  128. [Swift Deep Dive] Optional Binding, Chaining, and the Nil Coalescing Operator
//
//  Created by Eduard Tokarev on 24.07.2022.
//

struct MyOptional {
    var property = 123
    func method() {
        print("I am the struct's method")
    }
}

let myOptional: MyOptional?

//myOptional = nil

myOptional = MyOptional()

print(myOptional?.property)



//let text: String = myOptional ?? "I am the default value"
//
//print(text)

//if let safeOptional = myOptional {
//    let text: String = safeOptional
//    print(safeOptional)
//} else {
//    print("myOptional was found to be nil.")
//}
//
//if let myOptional = myOptional {
//    let text: String = myOptional
//}





